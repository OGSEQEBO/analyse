# analyse

analyse is a data analysis project completed by members of 'group 7' at Explore Data Science Academy in Cape Town.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install analyse

```bash
pip install analyse
```
## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
